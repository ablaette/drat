#' How to get started
#' 
#' bla bla
#' @keywords package
#' @docType package
#' @rdname polmineR.sampleCorpus-package
#' @name polmineR.sampleCorpus-package
NULL 

#' @import methods
NULL
